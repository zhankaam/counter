import React, {useState} from 'react';
import './App.css'
import {Buttons} from "./Buttons";
import {Count} from "./Count";

function App() {
    let [count, setCount] = useState(0)
    let maxValue = 5

    let increment = () => {
        if (maxValue === count) {
            return
        }
        setCount(count + 1)
    }

    let reset = () => {
        setCount(0)
    }

    return (<div className={"App"}>
        <div className={"App-wrapper"}>
            <div className={"App-wrapperCount"}>
                <Count count={count}/>
                </div>
            <div className={"App-wrapperButton"}>
                <Buttons
                    count={count}
                    increment={increment}
                    reset={reset}
                    maxValue={maxValue}
                />
            </div>
        </div>
    </div>)
}


export default App;
